plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.socialdownloader"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.socialdownloader"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
