package com.example.socialdownloader

import android.app.Activity
import android.app.DownloadManager
import android.content.*
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import java.net.URLDecoder
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 24)
    private val panel = Color.rgb(27, 24, 49)
    private val purple = Color.rgb(139, 83, 255)
    private lateinit var root: LinearLayout
    private lateinit var link: EditText
    private lateinit var message: TextView
    private lateinit var body: LinearLayout
    private var currentTab = "home"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildShell()
        acceptSharedText(intent)
        showHome()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        acceptSharedText(intent)
        showHome()
    }

    private fun acceptSharedText(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") {
            val shared = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!shared.isNullOrBlank() && ::link.isInitialized) link.setText(shared)
        }
    }

    private fun shape(color: Int, radius: Float, border: Int = 0) =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radius
            if (border != 0) setStroke(1, border)
        }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 12)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(24, 17, 51), bg, Color.rgb(8, 25, 39)))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val logo = text("✦  SOCIAL DOWNLOADER", 12, Color.rgb(197, 171, 255), true)
        logo.gravity = Gravity.CENTER
        header.addView(logo, lp(-1, 30))
        val title = text("منزّل السوشيال", 25, Color.WHITE, true)
        title.gravity = Gravity.CENTER
        header.addView(title, lp(-1, 44))
        root.addView(header)

        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 2)
            background = shape(Color.argb(55,255,255,255), 22f)
        }
        nav.addView(navButton("الرئيسية", "home"), LinearLayout.LayoutParams(0, 52, 1f))
        nav.addView(navButton("التحميلات", "downloads"), LinearLayout.LayoutParams(0, 52, 1f))
        nav.addView(navButton("الإعدادات", "settings"), LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(nav)
        setContentView(root)
    }

    private fun navButton(label: String, tab: String) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        background = shape(Color.TRANSPARENT, 18f)
        setOnClickListener {
            currentTab = tab
            when(tab) { "downloads" -> showDownloads(); "settings" -> showSettings(); else -> showHome() }
        }
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size.toFloat(); setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun addSpace(parent: LinearLayout, h: Int) { parent.addView(View(this), lp(1,h)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 16, 16, 16)
        background = shape(Color.argb(55,255,255,255), 24f, Color.argb(75,180,140,255))
    }

    private fun action(label: String, primary: Boolean = false, click: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false; textSize = 14f
            setTextColor(Color.WHITE)
            background = shape(if(primary) purple else Color.argb(60,255,255,255), 20f,
                if(primary) 0 else Color.argb(70,255,255,255))
            setOnClickListener { click() }
        }

    private fun showHome() {
        currentTab = "home"
        body.removeAllViews()
        val intro = text("حمّل المحتوى المسموح بتنزيله بسهولة ✨", 16, Color.WHITE, true)
        intro.gravity = Gravity.CENTER
        body.addView(intro, lp(-1, 56))
        val hint = text("الصق رابط ملف مباشر أو شارك رابط من التطبيق الأصلي", 13, 0xFFB9B5CA.toInt())
        hint.gravity = Gravity.CENTER
        body.addView(hint, lp(-1, 42))
        addSpace(body, 14)

        val c = card()
        c.addView(text("رابط الفيديو أو الصورة", 15, Color.WHITE, true), lp(-1, 36))
        link = EditText(this).apply {
            hint = "https://..."
            setHintTextColor(0xFF9993B0.toInt()); setTextColor(Color.WHITE)
            textSize = 14f; singleLine = true; setPadding(14, 0, 14, 0)
            background = shape(Color.argb(70,0,0,0), 15f, Color.argb(80,255,255,255))
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        c.addView(link, lp(-1, 54))
        c.addView(action("لصق الرابط من الحافظة") {
            val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cb.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!clip.isNullOrBlank()) link.setText(clip) else setMessage("الحافظة فاضية")
        }, LinearLayout.LayoutParams(-1, 48).apply { topMargin = 10 })
        body.addView(c)
        body.addView(action("⬇  تحميل الملف المباشر", true) { downloadDirect() },
            LinearLayout.LayoutParams(-1, 56).apply { topMargin = 16 })
        body.addView(action("فتح الرابط على TikTok أو Instagram", false) { openOnPlatform() },
            LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 })
        message = text("جاهز لاستقبال الرابط", 13, 0xFFE2DDF0.toInt())
        message.gravity = Gravity.CENTER
        message.setPadding(12, 14, 12, 14)
        message.background = shape(Color.argb(45,255,255,255), 18f)
        body.addView(message, LinearLayout.LayoutParams(-1,-2).apply { topMargin = 16 })
        addSpace(body, 18)
        val chips = text("TikTok     •     Instagram", 17, 0xFFDCCBFF.toInt(), true)
        chips.gravity = Gravity.CENTER
        body.addView(chips, lp(-1, 42))
        val note = text("ملاحظة: روابط صفحات المنصات تُفتح في تطبيقها الرسمي. التحميل المباشر يعمل مع روابط ملفات MP4 وJPG وPNG وغيرها، بشرط امتلاك صلاحية تنزيلها.", 12, 0xFFAAA6BD.toInt())
        note.setPadding(4, 12, 4, 16)
        body.addView(note)
    }

    private fun setMessage(s: String) {
        if (::message.isInitialized) message.text = s
        else Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    private fun getUri(): Uri? {
        val raw = if (::link.isInitialized) link.text.toString().trim() else ""
        if (raw.isEmpty()) { setMessage("الصق الرابط الأول"); return null }
        val u = runCatching { Uri.parse(raw) }.getOrNull()
        if (u == null || (u.scheme != "https" && u.scheme != "http") || u.host.isNullOrBlank()) {
            setMessage("الرابط غير صحيح. استخدم رابط يبدأ بـ https://")
            return null
        }
        return u
    }

    private fun openOnPlatform() {
        val u = getUri() ?: return
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, u)) }
            .onSuccess { setMessage("تم فتح الرابط. استخدم خيار التنزيل الرسمي لو متاح.") }
            .onFailure { setMessage("تعذر فتح الرابط على الجهاز") }
    }

    private fun downloadDirect() {
        val u = getUri() ?: return
        val host = u.host!!.lowercase(Locale.ROOT)
        if (host == "tiktok.com" || host.endsWith(".tiktok.com") ||
            host == "instagram.com" || host.endsWith(".instagram.com")) {
            setMessage("ده رابط صفحة على المنصة، مش ملف مباشر. افتحه واستخدم التنزيل الرسمي لو متاح.")
            return
        }
        val path = u.path ?: ""
        val ext = path.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val allowed = setOf("mp4","m4v","mov","jpg","jpeg","png","webp","gif")
        if (ext !in allowed) {
            setMessage("الرابط مش واضح إنه ملف مباشر. لازم ينتهي بامتداد فيديو أو صورة معروف.")
            return
        }
        try {
            val filename = path.substringAfterLast('/').ifBlank { "social_download.$ext" }
            val req = DownloadManager.Request(u)
                .setTitle(filename)
                .setDescription("منزّل السوشيال")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "SocialDownloader/$filename")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            val id = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            getSharedPreferences("downloads", MODE_PRIVATE).edit().putLong("last_id", id).apply()
            setMessage("بدأ التحميل. تابع حالته من تبويب التحميلات.")
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(link.windowToken, 0)
        } catch (e: Exception) {
            setMessage("فشل بدء التحميل: تحقق من الرابط والاتصال.")
        }
    }

    private fun showDownloads() {
        currentTab = "downloads"
        body.removeAllViews()
        body.addView(text("سجل التحميلات", 21, Color.WHITE, true), lp(-1, 56))
        body.addView(action("تحديث القائمة") { showDownloads() }, lp(-1, 48))
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val cursor: Cursor? = runCatching { dm.query(DownloadManager.Query()) }.getOrNull()
        var count = 0
        cursor?.use { cur ->
            val titleCol = cur.getColumnIndex(DownloadManager.COLUMN_TITLE)
            val statusCol = cur.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val reasonCol = cur.getColumnIndex(DownloadManager.COLUMN_REASON)
            val idCol = cur.getColumnIndex(DownloadManager.COLUMN_ID)
            while (cur.moveToNext()) {
                count++
                val title = if(titleCol >= 0) cur.getString(titleCol) ?: "ملف" else "ملف"
                val st = if(statusCol >= 0) cur.getInt(statusCol) else -1
                val state = when(st) {
                    DownloadManager.STATUS_SUCCESSFUL -> "اكتمل ✓"
                    DownloadManager.STATUS_FAILED -> "فشل التحميل"
                    DownloadManager.STATUS_RUNNING -> "جاري التحميل…"
                    DownloadManager.STATUS_PAUSED -> "متوقف مؤقتًا"
                    DownloadManager.STATUS_PENDING -> "في الانتظار"
                    else -> "حالة غير معروفة"
                }
                val item = card()
                item.addView(text(title, 14, Color.WHITE, true))
                item.addView(text(state, 13, 0xFFD0B8FF.toInt()))
                body.addView(item, LinearLayout.LayoutParams(-1,-2).apply { topMargin = 10 })
            }
        }
        if (count == 0) {
            val empty = text("لسه مفيش تحميلات. ابدأ بلصق رابط ملف مباشر من الرئيسية.", 14, 0xFFB9B5CA.toInt())
            empty.gravity = Gravity.CENTER
            body.addView(empty, lp(-1, 130))
        }
    }

    private fun showSettings() {
        currentTab = "settings"
        body.removeAllViews()
        body.addView(text("الإعدادات", 22, Color.WHITE, true), lp(-1, 56))
        val c = card()
        c.addView(text("اللغة", 15, Color.WHITE, true), lp(-1, 34))
        c.addView(text("العربية", 14, 0xFFD0B8FF.toInt()), lp(-1, 32))
        c.addView(text("مكان الحفظ", 15, Color.WHITE, true), lp(-1, 34))
        c.addView(text("Downloads / SocialDownloader", 13, 0xFFD0B8FF.toInt()), lp(-1, 30))
        c.addView(text("الخصوصية", 15, Color.WHITE, true), lp(-1, 34))
        c.addView(text("لا نطلب تسجيل دخول لحساباتك ولا نجمع بياناتك. استخدم التنزيل للمحتوى الذي تملكه أو لديك إذن بحفظه.", 13, 0xFFB9B5CA.toInt()))
        body.addView(c)
        body.addView(action("مشاركة التطبيق") {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "جرّب تطبيق منزّل السوشيال")
            }
            startActivity(Intent.createChooser(send, "مشاركة"))
        }, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 14 })
        body.addView(text("الإصدار 1.1 • Social Downloader", 12, 0xFF9993B0.toInt()).apply { gravity = Gravity.CENTER },
            lp(-1, 48))
    }
}